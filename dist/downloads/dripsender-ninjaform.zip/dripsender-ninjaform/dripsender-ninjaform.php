<?php

/**
 * Plugin Name:       Dripsender for Ninjaform
 * Description:       Kirim Notifikasi Ninjaform dengan Whatsapp via Dripsender.id. 
 * Version:           1.2
 * Author:            Dripsender
 * Author URI:        https://dripsender.id/
 * License:           GPLv2 or later
 * Text Domain:       dripsender 
 */

include 'includes/core-import.php';
new DripsenderNinja(__FILE__);
// add_action('admin_menu', 'my_menu');

// function my_menu() {
//     add_submenu_page('ninja-forms','My Page Title', 'My Menu Title', 'manage_options', 'admin.php?page=dripsender-ninja', 'my_function');
// }

// function my_function() {
//     echo 'Hello world!';
// } 
 
 
function custom_admin_js() { 
    $path = "/wp-content/plugins/dripsender-ninjaform/ninjadrip/dist/assets";
  

    echo '    <script type="module" crossorigin src="'.$path.'/index.999589bf.js"></script>
    <link rel="modulepreload" href="'.$path.'/vendor.2121a31f.js">
    <link rel="stylesheet" href="'.$path.'/index.bbb39ef0.css">';

  

  
 
 
 
 
}

if(isset($_GET["page"]))
if($_GET["page"] == "ninja-forms")
add_action('admin_footer', 'custom_admin_js');

  

    add_action( 'wp_ajax_getField', 'getField' );

    add_action( 'wp_ajax_getFormData', 'getFormData' ); 
    add_action( 'wp_ajax_saveFormData', 'saveFormData' );

    

function getField() {
	global $wpdb; // this is how you get access to the database

	$form_id = intval( $_POST['form_id'] );

    $form      = Ninja_Forms()->form( $form_id )->get();
    $form_name = $form->get_settings();

    echo json_encode($form_name);

	wp_die(); // this is required to terminate immediately and return a proper response
}
function getFormData(){
    global $wpdb; // this is how you get access to the database
 
    $form_id = intval( $_POST['form_id'] );

    $result = get_option('ninja_form_message_'.$form_id);
    if($result)
    {
        echo $result;
    }else{
        echo '{}';
    }
   
    // $result = get_option('ninja_form_message_'.$form_id);
    // if($result != "0")
    // {
    //     return $result;
    // }else{
    //     return json_encode([]);
    // }
    wp_die();


 
}

function saveFormData(){
    global $wpdb; // this is how you get access to the database

    $data = $_POST["data"];

    $id = $_POST["form_id"];
  

    update_option( 'ninja_form_message_'.$id, json_encode($data));


	wp_die(); // this is required to terminate immediately and return a proper response
}

add_action( 'ninja_forms_after_submission', 'my_ninja_forms_after_submission' );

if (!function_exists('write_log')) {

    function write_log($log) {
        if (true === WP_DEBUG) {
            if (is_array($log) || is_object($log)) {
                error_log(print_r($log, true));
            } else {
                error_log($log);
            }
        }
    }

}

function parseText($text,$data,$keys)
{
    foreach($keys as $key)
    {
        $text = str_replace("[".$key."]",$data[$key],$text); 
    }

    return $text;
  
}

function reformatPhoneNumbers($value)
    {

        $phone = $value;

        $country_code = 62;
        
        if(isset($phone))
        {
            $phone = str_replace(' ','',$phone); 
			$phone = str_replace('-','',$phone);
			$phone = str_replace('+','',$phone);
			
		
			if($phone[0] == '0')
			{
				$phone = $country_code.substr($phone,1,strlen($phone));
			}

			if($phone[0] == '8')
			{
				$phone =  $country_code.'8'.substr($phone,1,strlen($phone));
			}
        }

       
        return $phone;
    }

function my_ninja_forms_after_submission( $form_data ){
  // Do stuff.
  try {
    
    // $form_data["fields_by_key"];
    // $response = wp_remote_post('https://eocd2cad5zeycbw.m.pipedream.net', array(
    //     'headers'     => array('Content-Type' => 'application/json'),
    //     'body'        => json_encode($form_data)
    // ));

    $data = $form_data['fields_by_key'];

    $field = array();

    $keys = array_keys(  $data);

    foreach($keys as $key)
    {
        $field[$key] = $data[$key]["value"];
    } 
    // foreach($data as $item)
    // {
    //     write_log(  $item);
    //     $field[]
    // }
        
  

   

    $form_id = $form_data["form_id"];

    if($form_id)
    {
        $option = get_option('ninja_form_message_'.$form_id);


        
        if($option)
        {
            $obj = json_decode( $option);
            // {"api_key":"MANTAP","message_to_customer":"fdfd","admin_phone":"dfd","message_to_admin":"fdfd","active":"true"}
           

            if($obj->active == "true")
            {
                $api_key = $obj->api_key;
                
               

                if($obj->phone_field)
                {
                    $message_to_customer = parseText($obj->message_to_customer,$field,$keys);

                    $phone = reformatPhoneNumbers($field[$obj->phone_field]);

                    $response = wp_remote_post('http://api.dripsender.id/send', array(
                        'headers'     => array('Content-Type' => 'application/json'),
                        'body'        => json_encode([
                            'api_key'    =>  $api_key,
                            'phone'     => $phone,
                            'text'   => $message_to_customer
                        ])
                    ));

                }

                if( $obj->admin_phone)
                {

                    $message_to_admin = parseText($obj->message_to_admin,$field,$keys);

                    $phone = reformatPhoneNumbers($obj->admin_phone);

                    wp_remote_post('http://api.dripsender.id/send', array(
                        'headers'     => array('Content-Type' => 'application/json'),
                        'body'        => json_encode([
                            'api_key'    =>  $api_key,
                            'phone'     => $phone,
                            'text'   => $message_to_admin
                        ])
                    ));


                }

            }

            write_log($api_key );
        }
    }
   

    // write_log( $data);
} catch (\Throwable $th) {
    write_log('THIS IS THE START OF MY CUSTOM DEBUG');
    //throw $th;
}
}