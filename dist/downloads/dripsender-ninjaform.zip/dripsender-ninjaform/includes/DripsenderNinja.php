<?php

class DripsenderNinja
{

    public $prefix = 'dripsender_ninja';

    public $form_id = "";

    public function __construct($baseFile = null)
    {
        $this->init();
    }

    private function init()
    {
      
        // add_action('woocommerce_settings_tabs_settings_tab_dripsender', array($this, 'settings_tab'));
        // add_action('woocommerce_update_options_settings_tab_dripsender', array($this, 'update_settings'));
        add_filter( 'plugin_row_meta', array( $this, 'plugin_row_meta_link' ), 10, 4 );
  


     
        /*
         * Send new order admin SMS
         */
        // add_action('woocommerce_order_status_processing', array($triggerAPI, 'notify_send_admin_sms_for_woo_new_order'), 10, 1);
    }
    public function my_setting_section_callback_function(){
        echo "yes";
    }
 
	public function plugin_row_meta_link( $plugin_meta, $plugin_file, $plugin_data, $status ) {
       

		if ( isset( $plugin_data['Name'] ) && ( 'Dripsender for Ninjaform' === $plugin_data['Name'] ) ) {
		 
            $plugin_meta[] = '<a href="https://app.dripsender.id/whatsapp" target="_blank" >Dripsender Apps</a>';
		 
		}
		return $plugin_meta;
	}

   
    
}