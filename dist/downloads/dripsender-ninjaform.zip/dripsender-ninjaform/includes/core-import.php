<?php

/* 
 * Import plugin files.
 */
 
require 'DripsenderNinja.php'; 
// require 'SendTrigger.php';

