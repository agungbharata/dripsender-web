=== Dripsender for Ninjaform ===
Contributors: dripsender 
Requires at least: 3.0.1
Tested up to: 5.6
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= 1.1 =
  
* Initial Release