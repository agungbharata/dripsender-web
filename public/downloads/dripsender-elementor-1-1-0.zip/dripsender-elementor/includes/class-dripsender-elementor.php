<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Dripsender_Elementor {
    public function __construct() {
        add_action('elementor/elements/categories_registered', array($this, 'add_elementor_widget_categories'));
        add_action('elementor/widgets/widgets_registered', array($this, 'register_widgets'));
    }

    public function add_elementor_widget_categories($elements_manager) {
        $elements_manager->add_category(
            'dripsender',
            [
                'title' => __('Dripsender', 'dripsender-elementor'),
                'icon' => 'fa fa-plug',
            ]
        );
    }

    public function register_widgets($widgets_manager) {
        require_once(DRIPSENDER_ELEMENTOR_PATH . 'includes/widgets/class-dripsender-input-widget.php');
        require_once(DRIPSENDER_ELEMENTOR_PATH . 'includes/widgets/class-dripsender-button-widget.php');

        $widgets_manager->register_widget_type(new Dripsender_Input_Widget());
        $widgets_manager->register_widget_type(new Dripsender_Button_Widget());
    }

    // Add any other methods needed for the plugin functionality
}