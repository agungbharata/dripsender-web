<?php
class Dripsender_Button_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'dripsender_button';
    }

    public function get_title() {
        return __('Dripsender Button Action', 'dripsender-elementor');
    }

    public function get_icon() {
        return 'eicon-button';
    }

    public function get_categories() {
        return ['dripsender', 'basic'];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'dripsender-elementor'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => __('Button Text', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Submit', 'dripsender-elementor'),
            ]
        );

        $this->add_control(
            'webhook_url',
            [
                'label' => __('Webhook URL', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => __('https://example.com/webhook', 'dripsender-elementor'),
            ]
        );

        $this->add_control(
            'success_title',
            [
                'label' => __('Success Modal Title', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Success!', 'dripsender-elementor'),
            ]
        );

        $this->add_control(
            'success_message',
            [
                'label' => __('Success Modal Message', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Your form has been submitted successfully.', 'dripsender-elementor'),
            ]
        );

        $this->add_control(
            'error_title',
            [
                'label' => __('Error Modal Title', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Error', 'dripsender-elementor'),
            ]
        );

        $this->add_control(
            'error_message',
            [
                'label' => __('Error Modal Message', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('An error occurred while submitting the form. Please try again.', 'dripsender-elementor'),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Style', 'dripsender-elementor'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'button_alignment',
            [
                'label' => __('Button Alignment', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'dripsender-elementor'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'dripsender-elementor'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'dripsender-elementor'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'toggle' => true,
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => __('Text Color', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
            ]
        );

        $this->add_control(
            'button_background_color',
            [
                'label' => __('Background Color', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#06b6d4',
            ]
        );

        $this->add_control(
            'button_full_width',
            [
                'label' => __('Full Width Button', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'dripsender-elementor'),
                'label_off' => __('No', 'dripsender-elementor'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'facebook_pixel_section',
            [
                'label' => __('Facebook Pixel', 'dripsender-elementor'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'enable_facebook_pixel',
            [
                'label' => __('Enable Facebook Pixel', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'dripsender-elementor'),
                'label_off' => __('No', 'dripsender-elementor'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'facebook_pixel_id',
            [
                'label' => __('Facebook Pixel ID', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'enable_facebook_pixel' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'facebook_pixel_event',
            [
                'label' => __('Facebook Pixel Event', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'PageView' => __('PageView', 'dripsender-elementor'),
                    'Lead' => __('Lead', 'dripsender-elementor'),
                    'CompleteRegistration' => __('CompleteRegistration', 'dripsender-elementor'),
                    'Contact' => __('Contact', 'dripsender-elementor'),
                    'CustomEvent' => __('Custom Event', 'dripsender-elementor'),
                ],
                'default' => 'Lead',
                'condition' => [
                    'enable_facebook_pixel' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'facebook_pixel_custom_event',
            [
                'label' => __('Custom Event Name', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'enable_facebook_pixel' => 'yes',
                    'facebook_pixel_event' => 'CustomEvent',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $button_class = 'dripsender-button btn';
        $wrapper_class = 'dripsender-button-wrapper';
        $wrapper_style = 'text-align: ' . $settings['button_alignment'] . ';';
        $button_style = 'display: inline-block; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;';
        $button_style .= 'color: ' . $settings['button_text_color'] . '; background-color: ' . $settings['button_background_color'] . ';';
        
        if ($settings['button_full_width'] === 'yes') {
            $button_class .= ' w-full';
        }
        
        $modal_id = 'dripsender-modal-' . $this->get_id();
        ?>
        <div class="<?php echo esc_attr($wrapper_class); ?>" data-theme="light" style="<?php echo esc_attr($wrapper_style); ?>">
            <button class="<?php echo esc_attr($button_class); ?>"
                    style="<?php echo esc_attr($button_style); ?>"
                    data-webhook-url="<?php echo esc_attr($settings['webhook_url']); ?>"
                    data-success-title="<?php echo esc_attr($settings['success_title']); ?>"
                    data-success-message="<?php echo esc_attr($settings['success_message']); ?>"
                    data-error-title="<?php echo esc_attr($settings['error_title']); ?>"
                    data-error-message="<?php echo esc_attr($settings['error_message']); ?>"
                    data-modal-id="<?php echo esc_attr($modal_id); ?>"
                    <?php if ($settings['enable_facebook_pixel'] === 'yes'): ?>
                    data-fb-pixel="<?php echo esc_attr($settings['facebook_pixel_id']); ?>"
                    data-fb-event="<?php echo esc_attr($settings['facebook_pixel_event']); ?>"
                    <?php if ($settings['facebook_pixel_event'] === 'CustomEvent'): ?>
                    data-fb-custom-event="<?php echo esc_attr($settings['facebook_pixel_custom_event']); ?>"
                    <?php endif; ?>
                    <?php endif; ?>
            >
                <?php echo esc_html($settings['button_text']); ?>
            </button>
        </div>

        <!-- Daisy UI Modal -->
        <div data-theme="light" id="<?php echo esc_attr($modal_id); ?>" class="modal">
            <div class="modal-box">
                <h3 style="font-weight: bold; font-size: 1.125rem;" id="modal-title" class="font-bold text-lg"></h3>
                <p class="py-4 modal-message"></p>
                <div class="modal-action">
                    <button class="btn close-modal" style="<?php echo esc_attr($button_style); ?>">TUTUP</button>
                </div>
            </div>
        </div>
        <?php
    }
}