<?php
class Dripsender_Input_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'dripsender_input';
    }

    public function get_title() {
        return __('Dripsender Input', 'dripsender-elementor');
    }

    public function get_icon() {
        return 'eicon-text-field';
    }

    public function get_categories() {
        return ['dripsender', 'basic'];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'dripsender-elementor'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'input_type',
            [
                'label' => __('Input Type', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'text',
                'options' => [
                    'text' => __('Text', 'dripsender-elementor'),
                    'textarea' => __('Textarea', 'dripsender-elementor'),
                    'select' => __('Select', 'dripsender-elementor'),
                ],
            ]
        );

        $this->add_control(
            'label',
            [
                'label' => __('Label', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Input Label', 'dripsender-elementor'),
            ]
        );

        $this->add_control(
            'placeholder',
            [
                'label' => __('Placeholder', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Enter your text here', 'dripsender-elementor'),
            ]
        );

        $this->add_control(
            'required',
            [
                'label' => __('Required', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'dripsender-elementor'),
                'label_off' => __('No', 'dripsender-elementor'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'select_options',
            [
                'label' => __('Select Options', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'option_label',
                        'label' => __('Option Label', 'dripsender-elementor'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                    ],
                    [
                        'name' => 'option_value',
                        'label' => __('Option Value', 'dripsender-elementor'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                    ],
                ],
                'condition' => [
                    'input_type' => 'select',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Style', 'dripsender-elementor'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'label_size',
            [
                'label' => __('Label Size', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'sm',
                'options' => [
                    'xs' => __('Extra Small', 'dripsender-elementor'),
                    'sm' => __('Small', 'dripsender-elementor'),
                    'base' => __('Medium', 'dripsender-elementor'),
                    'lg' => __('Large', 'dripsender-elementor'),
                    'xl' => __('Extra Large', 'dripsender-elementor'),
                ],
            ]
        );

        $this->add_control(
            'label_color',
            [
                'label' => __('Label Color', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#495057',
            ]
        );

        $this->add_control(
            'input_color',
            [
                'label' => __('Input Color', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .dripsender-input' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'input_background_color',
            [
                'label' => __('Input Background Color', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .dripsender-input' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'input_focus_border_color',
            [
                'label' => __('Focus Border Color', 'dripsender-elementor'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#06b6d4',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $input_class = 'dripsender-input w-full px-3 py-2 border border-gray-300 rounded-md transition duration-150 ease-in-out';
        $input_name = strtolower(str_replace(' ', '_', $settings['label']));
        $focus_color = $settings['input_focus_border_color'];
        $label_class = 'dripsender-label block font-bold mb-1';
        $label_size = $this->get_label_font_size($settings['label_size']);
        $label_color = $settings['label_color'];
        ?>
        <style>
            #dripsender-input-<?php echo esc_attr($this->get_id()); ?> .dripsender-input:focus {
                border-color: <?php echo esc_attr($focus_color); ?> !important;
                box-shadow: 0 0 0 1px <?php echo esc_attr($focus_color); ?> !important;
                outline: none !important;
            }
        </style>
        <div id="dripsender-input-<?php echo esc_attr($this->get_id()); ?>" class="dripsender-input-wrapper mb-4">
            <label class="<?php echo esc_attr($label_class); ?>" 
                   for="<?php echo esc_attr($input_name); ?>"
                   style="color: <?php echo esc_attr($label_color); ?>; font-size: <?php echo esc_attr($label_size); ?>;">
                <?php echo esc_html($settings['label']); ?>
            </label>
            <?php if ($settings['input_type'] === 'text'): ?>
                <input type="text" 
                       id="<?php echo esc_attr($input_name); ?>"
                       name="<?php echo esc_attr($input_name); ?>" 
                       class="<?php echo esc_attr($input_class); ?>" 
                       placeholder="<?php echo esc_attr($settings['placeholder']); ?>" 
                       <?php echo $settings['required'] === 'yes' ? 'required' : ''; ?>>
            <?php elseif ($settings['input_type'] === 'textarea'): ?>
                <textarea id="<?php echo esc_attr($input_name); ?>"
                          name="<?php echo esc_attr($input_name); ?>" 
                          class="<?php echo esc_attr($input_class); ?>" 
                          placeholder="<?php echo esc_attr($settings['placeholder']); ?>" 
                          <?php echo $settings['required'] === 'yes' ? 'required' : ''; ?> 
                          rows="3"></textarea>
            <?php elseif ($settings['input_type'] === 'select'): ?>
                <select id="<?php echo esc_attr($input_name); ?>"
                        name="<?php echo esc_attr($input_name); ?>" 
                        class="<?php echo esc_attr($input_class); ?>" 
                        <?php echo $settings['required'] === 'yes' ? 'required' : ''; ?>>
                    <?php foreach ($settings['select_options'] as $option): ?>
                        <option value="<?php echo esc_attr($option['option_value']); ?>">
                            <?php echo esc_html($option['option_label']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            <?php endif; ?>
        </div>
        <?php
    }

    private function get_label_font_size($size) {
        $font_sizes = [
            'xs' => '0.75rem',
            'sm' => '0.875rem',
            'base' => '1rem',
            'lg' => '1.125rem',
            'xl' => '1.25rem',
        ];
        return isset($font_sizes[$size]) ? $font_sizes[$size] : '0.875rem';
    }
}