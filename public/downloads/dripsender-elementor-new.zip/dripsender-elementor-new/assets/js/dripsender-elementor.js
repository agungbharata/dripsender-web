(function($) {
    'use strict';

    $(document).ready(function() {
        // Function to collect form data
        function collectFormData() {
            var formData = {};
            var inputCount = 0;
            $('.dripsender-input').each(function() {
                var $input = $(this);
                var value = $input.val();
                var key;

                // Determine the key based on input count
                if (inputCount === 0) {
                    key = 'name';
                } else if (inputCount === 1) {
                    key = 'phone';
                } else {
                    // For subsequent inputs, use the label text (converted to lowercase and underscores)
                    var label = $input.closest('.dripsender-input-wrapper').find('label').text().trim();
                    key = label.toLowerCase().replace(/\s+/g, '_');
                }

                // Set the value in formData
                if ($input.is(':checkbox')) {
                    formData[key] = $input.is(':checked');
                } else if ($input.is('select[multiple]')) {
                    formData[key] = $input.val() || [];
                } else {
                    formData[key] = value;
                }

                inputCount++;
            });
            return formData;
        }

        // Function to validate form data
        function validateFormData(formData) {
            var isValid = true;
            var inputCount = 0;
            $('.dripsender-input').each(function() {
                var $input = $(this);
                var key = (inputCount === 0) ? 'name' : (inputCount === 1 ? 'phone' : $input.attr('name'));
                
                if ($input.prop('required') && !formData[key]) {
                    isValid = false;
                    $input.addClass('input-error');
                } else {
                    $input.removeClass('input-error');
                }
                inputCount++;
            });
            return isValid;
        }

        // Function to show modal
        function showModal(title, message, isError, modalId) {
            const $modal = $(`#${modalId}`);
            $modal.find('#modal-title').text(title);
            $modal.find('.modal-message').text(message);
            $modal.addClass('modal-open');

            // Close modal when clicking the close button or outside the modal
            $modal.find('.close-modal, .modal-backdrop').on('click', function() {
                $modal.removeClass('modal-open');
            });
        }

        // Function to trigger Facebook Pixel event
        function triggerFacebookPixelEvent(eventName, eventData) {
            if (typeof fbq !== 'undefined') {
                fbq('track', eventName, eventData);
                console.log('Facebook Pixel event triggered:', eventName, eventData);
            }
        }

        // Handle form submission
        $('.dripsender-button').on('click', function(e) {
            e.preventDefault();

            var $button = $(this);
            var webhookUrl = $button.data('webhook-url');
            var successTitle = $button.data('success-title');
            var successMessage = $button.data('success-message');
            var errorTitle = $button.data('error-title');
            var errorMessage = $button.data('error-message');
            var modalId = $button.data('modal-id');
            var responsePageEnabled = $button.data('response-enable');
            var responsePageUrl = $button.data('response-page');

            // Collect and validate form data
            var formData = collectFormData();
            if (!validateFormData(formData)) {
                showModal('Validation Error', 'Please fill in all required fields.', true, modalId);
                return;
            }

            // Format data for Dripsender
            var dripsenderData = formData

            // Disable button and show loading state
            $button.prop('disabled', true).text('Sending...');

            // Send data to webhook
            $.ajax({
                url: webhookUrl,
                type: 'POST',
                data: JSON.stringify(dripsenderData),
                contentType: 'application/json',
                success: function(response) {
                    // Store submission
                    
                    if (responsePageEnabled === 'yes' && responsePageUrl) {
                        window.location.href = responsePageUrl;
                    } else {
                        showModal(successTitle, successMessage, false, modalId);
                        // Clear form fields after successful submission
                        $('.dripsender-input').val('');
                    }

                    // Submit to Elementor form submission
                    if (typeof elementorProFrontend !== 'undefined') {
                        elementorProFrontend.modules.forms.submitForm({
                            id: $button.closest('form').attr('id'),
                            fields: formData
                        });
                    }

                    // Trigger Facebook Pixel event if enabled
                    if ($button.data('fb-pixel')) {
                        var eventName = $button.data('fb-event');
                        if (eventName === 'CustomEvent') {
                            eventName = $button.data('fb-custom-event');
                        }
                        triggerFacebookPixelEvent(eventName, formData);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error details:', {
                        status: status,
                        error: error,
                        responseText: xhr.responseText
                    });
                    showModal(errorTitle, errorMessage, true, modalId);
                },
                complete: function() {
                    // Re-enable button and restore original text
                    $button.prop('disabled', false).text($button.data('original-text') || 'Submit');
                }
            });
        });

        // Store original button text
        $('.dripsender-button').each(function() {
            $(this).data('original-text', $(this).text());
        });

        // Add input event listeners for real-time validation
        $('.dripsender-input').on('input', function() {
            var $input = $(this);
            if ($input.prop('required') && !$input.val()) {
                $input.addClass('input-error');
            } else {
                $input.removeClass('input-error');
            }
        });

        // Initialize Facebook Pixel if enabled
        $('.dripsender-button').each(function() {
            var $button = $(this);
            var pixelId = $button.data('fb-pixel');
            if (pixelId && typeof fbq === 'undefined') {
                !function(f,b,e,v,n,t,s)
                {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
                n.callMethod.apply(n,arguments):n.queue.push(arguments)};
                if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
                n.queue=[];t=b.createElement(e);t.async=!0;
                t.src=v;s=b.getElementsByTagName(e)[0];
                s.parentNode.insertBefore(t,s)}(window, document,'script',
                'https://connect.facebook.net/en_US/fbevents.js');
                fbq('init', pixelId);
                fbq('track', 'PageView');
                console.log('Facebook Pixel initialized with ID:', pixelId);
            }
        });
    });
})(jQuery); 

