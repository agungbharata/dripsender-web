<?php
/**
 * Plugin Name: Dripsender Elementor
 * Description: Custom Elementor form Input for Dripsender integration and Pixel
 * Version: 1.0.0
 * Author: Dripsender
 * Author URI: https://wwww.dripsender.id
 * Text Domain: dripsender-elementor
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Define plugin constants
define('DRIPSENDER_ELEMENTOR_VERSION', '1.0.0');
define('DRIPSENDER_ELEMENTOR_FILE', __FILE__);
define('DRIPSENDER_ELEMENTOR_PATH', plugin_dir_path(DRIPSENDER_ELEMENTOR_FILE));
define('DRIPSENDER_ELEMENTOR_URL', plugin_dir_url(DRIPSENDER_ELEMENTOR_FILE));

// Include the main plugin class
require_once DRIPSENDER_ELEMENTOR_PATH . 'includes/class-dripsender-elementor.php';

// Initialize the plugin
function dripsender_elementor_init() {
    // Check if Elementor is active
    if (!did_action('elementor/loaded')) {
        add_action('admin_notices', 'dripsender_elementor_fail_load');
        return;
    }

    // Load plugin when Elementor is loaded
    add_action('elementor/init', 'dripsender_elementor_load');
}
add_action('plugins_loaded', 'dripsender_elementor_init');

// Admin notice if Elementor is not active
function dripsender_elementor_fail_load() {
    $message = sprintf(
        esc_html__('Dripsender Formbuilder for Elementor requires Elementor plugin to be active. Please install and activate Elementor.', 'dripsender-elementor')
    );
    $html_message = sprintf('<div class="error">%s</div>', wpautop($message));
    echo wp_kses_post($html_message);
}

// Load plugin
function dripsender_elementor_load() {
    // Load the main plugin class
    $dripsender_elementor = new Dripsender_Elementor();
}

// Enqueue Tailwind CSS, DaisyUI, and custom CSS
function dripsender_elementor_enqueue_styles() {
    wp_enqueue_style('tailwindcss', 'https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css', array(), DRIPSENDER_ELEMENTOR_VERSION);
    wp_enqueue_style('daisyui', 'https://cdn.jsdelivr.net/npm/daisyui@2.6.0/dist/full.css', array('tailwindcss'), DRIPSENDER_ELEMENTOR_VERSION);
    
    // Enqueue custom CSS if not disabled in options
    $options = get_option('dripsender_elementor_options');
    if (!isset($options['disable_custom_css']) || !$options['disable_custom_css']) {
        wp_enqueue_style('dripsender-elementor', DRIPSENDER_ELEMENTOR_URL . 'assets/css/dripsender-elementor.css', array('tailwindcss', 'daisyui'), DRIPSENDER_ELEMENTOR_VERSION);
    }
}
add_action('wp_enqueue_scripts', 'dripsender_elementor_enqueue_styles');
add_action('elementor/editor/before_enqueue_scripts', 'dripsender_elementor_enqueue_styles');

// Enqueue JavaScript
function dripsender_elementor_enqueue_scripts() {
    wp_enqueue_script('dripsender-elementor', DRIPSENDER_ELEMENTOR_URL . 'assets/js/dripsender-elementor.js', array('jquery'), DRIPSENDER_ELEMENTOR_VERSION, true);
}
add_action('wp_enqueue_scripts', 'dripsender_elementor_enqueue_scripts');
add_action('elementor/frontend/after_enqueue_scripts', 'dripsender_elementor_enqueue_scripts');


// Note: Category registration and widget registration are now handled in the main Dripsender_Elementor class