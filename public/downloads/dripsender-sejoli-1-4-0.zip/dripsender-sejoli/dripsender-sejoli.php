<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://dripsender.id
 * @since             1.2
 * @package           Drip_Sejoli
 *
 * @wordpress-plugin
 * Plugin Name:       Dripsender for Sejoli
 * Plugin URI:        https://dripsender.id
 * Description:       Installer whatsapp notifikasi dripsender untuk sejoli
 * Version:           1.4.0
 * Author:            Dripsender
 * Author URI:        https://dripsender.id
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       dripsender-sejoli
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'DRIP_SEJOLI_VERSION', '1.0.1' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-drip-sejoli-activator.php
 */
function activate_drip_sejoli() {
	if (SEJOLISA_DIR) {
		copy(plugin_dir_path( __FILE__ ) . 'includes/dripsender.php', SEJOLISA_DIR . '/notification-media/dripsender.php');

		// Backup the original notification.php file
		copy(SEJOLISA_DIR . '/admin/notification.php', SEJOLISA_DIR . '/admin/notification.php.backup');

		copy(plugin_dir_path( __FILE__ ) . 'includes/notification.php', SEJOLISA_DIR . '/admin/notification.php');
	}
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-drip-sejoli-deactivator.php
 */
function deactivate_drip_sejoli() {
	if (SEJOLISA_DIR) {
		// Restore the original notification.php file from backup
		if (file_exists(SEJOLISA_DIR . '/admin/notification.php.backup')) {
			copy(SEJOLISA_DIR . '/admin/notification.php.backup', SEJOLISA_DIR . '/admin/notification.php');
			unlink(SEJOLISA_DIR . '/admin/notification.php.backup');
		}

		// Remove dripsender.php from notification-media
		if (file_exists(SEJOLISA_DIR . '/notification-media/dripsender.php')) {
			unlink(SEJOLISA_DIR . '/notification-media/dripsender.php');
		}
	}
}

register_activation_hook( __FILE__, 'activate_drip_sejoli' );
register_deactivation_hook( __FILE__, 'deactivate_drip_sejoli' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */

if ( !defined('ABSPATH') ) {
	define('ABSPATH', dirname(__FILE__) . '/');
}
include 'includes/DripsenderApps.php';
new DripsenderApps(__FILE__);
