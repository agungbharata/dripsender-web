<?php

class DripsenderApps
{
    
    private $sejoli_dir = "";

    public function __construct($baseFile = null)
    {
        $this->init();
    }

    private function init()
    {
        /*
         * Add Dripsender to woo-commerce settings.
         */ 
        add_filter( 'plugin_row_meta', array( $this, 'plugin_row_meta_link' ), 10, 4 );
          
 

        if(isset($_GET['activate_dripsender_sejoli']) && isset($_GET['folder']))
        { 
          
            copy(plugin_dir_path( __FILE__ ) . 'dripsender.php', urldecode($_GET['folder']).'/notification-media/dripsender.php');

            $str=file_get_contents(urldecode($_GET['folder']).'/admin/notification.php');

//replace something in the file string - this is a VERY simple example
$str=str_replace("require_once( SEJOLISA_DIR . 'notification-media/starsender.php');", "require_once( SEJOLISA_DIR . 'notification-media/dripsender.php');",$str);
$str=str_replace("'starsender'    => new \SejoliSA\NotificationMedia\StarSender,", "'dripsender.id'    => new \SejoliSA\NotificationMedia\DripSender,",$str);
$str=str_replace("'starsender'    => new \SejoliSA\NotificationMedia\DripSender,", "'dripsender.id'    => new \SejoliSA\NotificationMedia\DripSender,",$str);



//write the entire string
file_put_contents(urldecode($_GET['folder']).'/admin/notification.php', $str);

		    // copy(plugin_dir_path( __FILE__ ) . 'notification.php', urldecode($_GET['folder']).'/admin/notification.php');

           
    
            add_action( 'admin_notices',  array( $this, 'sample_admin_notice__success' ), 10, 5  );
        }
 
    }

    function sample_admin_notice__success() {
        ?>
        <div class="notice notice-success is-dismissible">
            <p><?php _e( 'Dripsender Notifikasi telah ditambahkan ke sejoli!', 'dripsender notice' ); ?></p>
        </div>
        <?php
    }
    

    
 

    public function plugin_row_meta_link( $plugin_meta, $plugin_file, $plugin_data, $status ) {
       
       
   
        $folder  = urlencode(SEJOLISA_DIR);

       

		if ( isset( $plugin_data['Name'] ) && ( 'Dripsender for Sejoli' === $plugin_data['Name'] ) ) {
          
            $plugin_meta[] = '<a href="/wp-admin/plugins.php?activate_dripsender_sejoli=true&folder='.$folder.'". >Aktifkan Dripsender for Sejoli</a>';
            $plugin_meta[] = '<a href="/wp-admin/admin.php?page=crb_carbon_fields_container_notifikasi.php" >Pengaturan</a>';
		 
		}
		return $plugin_meta;
	}

   
}
